
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional






IRREGULAR = {
    "sent": "send", "paid": "pay", "made": "make", "built": "build",
    "found": "find", "given": "give", "written": "write", "wrote": "write",
    "done": "do", "taken": "take", "took": "take", "gone": "go",
    "sold": "sell", "told": "tell", "kept": "keep", "held": "hold",
    "met": "meet", "drawn": "draw", "shown": "show", "known": "know",
    "seen": "see", "chosen": "choose", "chose": "choose", "spent": "spend",
    "left": "leave", "lost": "lose", "got": "get", "gotten": "get",
    "bought": "buy", "brought": "bring", "caught": "catch",
    "taught": "teach", "thought": "think", "sought": "seek", "dealt": "deal",
    "felt": "feel", "sat": "sit", "began": "begin", "begun": "begin",
    "ran": "run", "sang": "sing", "read": "read", "put": "put", "set": "set",
    "cut": "cut", "hit": "hit", "let": "let", "split": "split",
    "shut": "shut", "cost": "cost", "hurt": "hurt", "spread": "spread",
}



STOPWORDS = frozenset("""
a an the this that these those it its it's their they them there here
and or but so then than if when while once until after before
is are was were be been being am do does did done doing
have has had having will would shall should can could may might must
of in on at to for from with without by into onto over under about as
not no nor never any all each every some both either neither
i you he she we us our your my his her one two three
what which who whom whose how why where
""".split())


def stem(word: str) -> str:
    
    w = word.lower().strip("_")
    if w in IRREGULAR:
        return IRREGULAR[w]
    for suf, keep in (("ingly", 5), ("edly", 4), ("ing", 5), ("ies", 4),
                      ("ied", 4), ("ed", 4), ("es", 4), ("ly", 4), ("s", 3)):
        if w.endswith(suf) and len(w) >= keep:
            w = w[: -len(suf)]
            if suf in ("ies", "ied"):
                w += "y"
            break
    if len(w) > 3 and w.endswith("e"):
        w = w[:-1]
    if len(w) > 3 and w[-1] == w[-2] and w[-1] not in "aeiou":
        w = w[:-1]          
    return w


WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]*")


def stem_index(text: str) -> dict[str, int]:
    
    idx: dict[str, int] = {}
    toks = [(m.group(0), m.start()) for m in WORD_RE.finditer(text)]

    def put(key: str, pos: int) -> None:
        if key and key not in idx:
            idx[key] = pos

    for i, (w, pos) in enumerate(toks):
        put(stem(w), pos)
        if "_" in w:
            for part in w.split("_"):
                put(stem(part), pos)
        if i + 1 < len(toks):
            put(stem(w + toks[i + 1][0]), pos)
    return idx


def content_stems(text: str) -> list[str]:
    return [stem(w) for w in WORD_RE.findall(text)
            if w.lower() not in STOPWORDS]






_OPS_BEFORE = {
    "below": "<", "under": "<", "less than": "<", "cheaper than": "<",
    "lower than": "<", "at most": "<=", "no more than": "<=",
    "not more than": "<=", "at or below": "<=", "up to": "<=",
    "above": ">", "over": ">", "more than": ">", "higher than": ">",
    "greater than": ">", "at least": ">=", "at or above": ">=",
    "no less than": ">=", "starting at": ">=",
}
_OPS_AFTER = {
    "or more": ">=", "or above": ">=", "or greater": ">=", "or higher": ">=",
    "or less": "<=", "or below": "<=", "or under": "<=", "or lower": "<=",
}

_NUM_BEFORE_RE = re.compile(
    r"\b(" + "|".join(sorted(_OPS_BEFORE, key=len, reverse=True))
    + r")\s+\$?\s*([0-9][0-9,]*)", re.I)
_NUM_AFTER_RE = re.compile(
    r"\$?\s*\b([0-9][0-9,]*)\s+(" + "|".join(sorted(_OPS_AFTER, key=len,
                                                    reverse=True)) + r")\b",
    re.I)




QUANTITY_NOUNS = ("price", "prices", "cost", "costs", "fare", "fares",
                  "amount", "total", "budget", "ceiling", "spend", "charge",
                  "fee", "fees", "rate")


@dataclass(frozen=True)
class NumClause:
    op: str
    value: int
    start: int
    end: int
    noun: Optional[str] = None


def find_num_clause(text: str) -> Optional[NumClause]:
    
    cands: list[NumClause] = []
    for m in _NUM_BEFORE_RE.finditer(text):
        cands.append(NumClause(_OPS_BEFORE[m.group(1).lower()],
                               int(m.group(2).replace(",", "")),
                               m.start(), m.end()))
    for m in _NUM_AFTER_RE.finditer(text):
        cands.append(NumClause(_OPS_AFTER[m.group(2).lower()],
                               int(m.group(1).replace(",", "")),
                               m.start(), m.end()))
    if not cands:
        return None
    c = min(cands, key=lambda c: c.start)
    noun = None
    for m in re.finditer(r"\b(" + "|".join(QUANTITY_NOUNS) + r")\b",
                         text, re.I):
        noun = m.group(1).lower()
        if m.start() < c.start:
            break
    return NumClause(c.op, c.value, c.start, c.end, noun)


def quantity_var(noun: Optional[str]) -> str:
    
    if not noun:
        return "amount"
    s = stem(noun)
    
    
    if s in ("pric", "fare", "cost", "charg", "fee", "ceil", "spend",
             "budget", "rate"):
        return "price"
    return {"amount": "amount", "total": "total"}.get(s, s or "amount")






DONE_RE = re.compile(
    r"(?:your\s+job\s+is\s+finished\s+when"
    r"|you(?:'re|\s+are)\s+done\s+when"
    r"|(?:the\s+)?(?:job|task|skill|work)\s+is\s+"
    r"(?:finished|complete|completed|done)\s+when"
    r"|this\s+is\s+done\s+when"
    r"|success\s+means"
    r"|definition\s+of\s+done\s*:)"
    r"(.{0,400}?)(?<!\d)\.(?:\s|$)", re.I | re.S)

BOLD_RE = re.compile(r"\*\*([^*]+?)\*\*")


_PARTICIPLE_RE = re.compile(r"\b([A-Za-z]{3,})\b")


def _is_participle(word: str) -> bool:
    w = word.lower()
    if w in STOPWORDS or w in QUANTITY_NOUNS:
        
        
        
        return False
    return w.endswith("ed") or w in IRREGULAR


def condition_predicate(phrase: str) -> Optional[str]:
    
    words = [m.group(1) for m in _PARTICIPLE_RE.finditer(phrase)
             if m.group(1).lower() not in STOPWORDS]
    heads = [w for w in words if _is_participle(w)]
    if not heads:
        return None
    head = heads[-1].lower()
    if (len(words) == 2 and words[1].lower() == head
            and not _is_participle(words[0])
            and words[0].lower() not in QUANTITY_NOUNS):
        return words[0].lower() + "_" + head
    return head


@dataclass
class Condition:
    
    text: str
    predicate: Optional[str] = None
    num: Optional[NumClause] = None
    context: str = ""


def goal_clause(prose: str) -> Optional[str]:
    
    m = DONE_RE.search(prose)
    return m.group(1) if m else None


def parse_goal(prose: str) -> tuple[list[Condition], Optional[str]]:
    
    m = DONE_RE.search(prose)
    if not m:
        return [], None
    clause = m.group(1)
    parts = list(BOLD_RE.finditer(clause))
    if not parts:
        return [], None
    conds: list[Condition] = []
    var: Optional[str] = None
    prev = 0
    for b in parts:
        text = " ".join(b.group(1).split())
        context = " ".join(clause[prev:b.end(1)].replace("*", " ").split())
        prev = b.end()
        num = find_num_clause(text)
        rest = text
        if num is not None:
            rest = (text[:num.start] + " " + text[num.end:]).strip()
            if var is None:
                var = quantity_var(num.noun)
        conds.append(Condition(text, condition_predicate(rest), num, context))
    return conds, var






ROLE_CUE_RE = re.compile(
    r"(?:participants?\s+take\s+part"
    r"|participants?\s*:"
    r"|carr(?:y|ies)\s+out\s+this\s+skill"
    r"|take\s+part\s+in\s+this\s+skill"
    r"|roles?\s*:)", re.I)

_ROLE_NAME_RE = re.compile(
    r"\*\*([A-Za-z][A-Za-z0-9 _-]{0,24}?)\*\*(?:\s*\(`([A-Za-z][\w-]*)`\))?")


@dataclass
class Role:
    name: str                       
    aliases: frozenset              


def parse_roles(prose: str) -> list[Role]:
    
    roles: list[Role] = []
    seen: set[str] = set()
    for cue in ROLE_CUE_RE.finditer(prose):
        
        start = prose.rfind("\n\n", 0, cue.start()) + 1
        end = prose.find("\n\n", cue.end())
        sentence = prose[start: end if end != -1 else len(prose)]
        for m in _ROLE_NAME_RE.finditer(sentence):
            display = " ".join(m.group(1).split()).lower()
            if not re.fullmatch(r"[a-z][a-z0-9 _-]*", display):
                continue
            rid = (m.group(2) or display).lower().replace(" ", "_")
            if rid in seen:
                continue
            seen.add(rid)
            roles.append(Role(rid, frozenset({rid, display,
                                              display.replace(" ", "_")})))
    return roles






HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.M)
STEP_RE = re.compile(r"^ {0,3}(\d+)[.)]\s+")
BULLET_RE = re.compile(r"^(\s*)[-*+]\s+")


@dataclass
class Section:
    title: str
    body: str


def split_sections(prose: str) -> list[Section]:
    
    out: list[Section] = []
    marks = list(HEADING_RE.finditer(prose))
    if not marks or marks[0].start() > 0:
        out.append(Section("", prose[: marks[0].start() if marks else len(prose)]))
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(prose)
        out.append(Section(m.group(2).strip(), prose[m.end(): end]))
    return out


def find_section(sections: list[Section], pattern: str) -> Optional[Section]:
    rx = re.compile(pattern, re.I)
    for s in sections:
        if rx.search(s.title):
            return s
    return None


def numbered_steps(body: str) -> list[str]:
    
    lines = body.split("\n")
    steps: list[list[str]] = []
    cur: Optional[list[str]] = None
    pending: list[str] = []
    for line in lines:
        if STEP_RE.match(line):
            if cur is not None:
                steps.append(cur)
            cur = [line]
            pending = []
        elif cur is not None:
            if not line.strip():
                pending.append(line)
            elif line[:1].isspace():
                cur.extend(pending)
                pending = []
                cur.append(line)
            else:
                steps.append(cur)
                cur = None
                pending = []
    if cur is not None:
        steps.append(cur)
    return ["\n".join(s) for s in steps]





LOOP_OPEN_RE = re.compile(r"\A\s*(?:loop|repeat)\s*:\s*\Z", re.I)
_LEAVE_RE = re.compile(
    r"\b(?:after|once|outside|exits?|exited|leaves?|leaving|left|ends?|ended"
    r"|finished|done\s+with)\b", re.I)


def _closes_loop(line: str) -> bool:
    return (bool(re.search(r"\bloop\b", line, re.I))
            and bool(_LEAVE_RE.search(line))
            and not STEP_RE.match(line) and not BULLET_RE.match(line)
            and not line[:1].isspace())


def split_loop_segments(body: str) -> list[tuple[str, str]]:
    
    segs: list[tuple[str, str]] = []
    kind = "seq"
    cur: list[str] = []
    for line in body.split("\n"):
        if kind == "seq" and LOOP_OPEN_RE.match(line):
            segs.append((kind, "\n".join(cur)))
            cur, kind = [], "loop"
            continue
        if kind == "loop" and _closes_loop(line):
            segs.append((kind, "\n".join(cur)))
            cur, kind = [], "seq"
            continue
        cur.append(line)
    segs.append((kind, "\n".join(cur)))
    return [s for s in segs if s[1].strip()]




CONTINUE_RE = re.compile(
    r"\b(?:go(?:es)?\s+back\s+to|going\s+back\s+to|start\s+(?:again|over)"
    r"|starts\s+(?:again|over)|round\s+again|again\s+from\s+the\s+(?:top|start)"
    r"|repeat(?:s)?\s+(?:the\s+loop|from\s+the\s+(?:top|start)))\b", re.I)


def split_bullets(text: str) -> tuple[str, list[str]]:
    
    lines = text.split("\n")
    head: list[str] = []
    bullets: list[list[str]] = []
    indent: Optional[int] = None
    pending: list[str] = []
    closed = False
    for line in lines:
        m = BULLET_RE.match(line)
        if m and not closed and (indent is None or len(m.group(1)) <= indent):
            indent = len(m.group(1))
            bullets.append([line])
            pending = []
        elif bullets and not closed:
            if not line.strip():
                pending.append(line)
            elif line[:1].isspace():
                bullets[-1].extend(pending)
                pending = []
                bullets[-1].append(line)
            else:
                closed = True
        elif not bullets:
            head.append(line)
    return "\n".join(head), ["\n".join(b) for b in bullets]


def sentences(text: str) -> list[str]:
    
    flat = " ".join(text.split())
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", flat) if s.strip()]






INVOKE_RE = re.compile(
    r"\b(?:via|use[sd]?|using|call(?:s|ed|ing)?|invoke[sd]?|invoking"
    r"|run(?:s|ning)?|through)"
    r"\s+(?:the\s+)?`([A-Za-z][A-Za-z0-9_.:-]*)`",
    re.I,
)



NEGATION_RE = re.compile(r"\b(?:not|never|without|instead\s+of)\b", re.I)


def negated_before(text: str, pos: int, window: int = 24) -> bool:
    return bool(NEGATION_RE.search(text[max(0, pos - window):pos]))
