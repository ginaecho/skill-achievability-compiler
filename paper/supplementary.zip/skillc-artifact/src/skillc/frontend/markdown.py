
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Optional

import yaml

from ..pack import PackError, validate_pack
from ..profiles import Profile, normalize_tool
from . import semantic
from .prose import INVOKE_RE, NEGATION_RE

FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n?", re.S)
FENCE_RE = re.compile(r"^(```+|~~~+)([^\n]*)\n(.*?)^\1\s*$\n?", re.S | re.M)
TOOLS_LINE_RE = re.compile(
    r"^\s*(?:\*\*)?tools(?:\s+available)?(?:\*\*)?\s*:\s*(.+)$", re.I | re.M)

AGENT_TOOL_RE = re.compile(r"\A(?:[a-z][a-z0-9]*(?:_[a-z0-9]+)+|[A-Z][A-Za-z0-9]*)\Z")
SHELL_TOKEN_RE = re.compile(r"\A[a-z][a-z0-9+.-]*\Z")


_NEGATION_BEFORE_VERB_RE = NEGATION_RE

SHELL_CAP = "bash"
PACK_FENCE_TAG = "skillc-pack"


@dataclass
class Invocation:
    
    raw: str            
    tool: str           
    kind: str           
    line: int           


@dataclass
class CompileResult:
    pack: dict
    name: str
    profile: str
    declared: dict[str, str] = field(default_factory=dict)  
    invocations: list[Invocation] = field(default_factory=list)
    embedded: bool = False           
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)   


def parse_frontmatter(text: str) -> tuple[dict, str]:
    
    m = FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    body = text[m.end():]
    try:
        meta = yaml.safe_load(m.group(1))
    except yaml.YAMLError:
        return {}, body
    return (meta if isinstance(meta, dict) else {}), body


def _tool_list(value) -> list[str]:
    
    if value is None:
        return []
    if isinstance(value, str):
        return [t.strip() for t in value.split(",") if t.strip()]
    if isinstance(value, list):
        return [str(t).strip() for t in value if str(t).strip()]
    return []


def _strip_fences(body: str) -> tuple[str, Optional[dict]]:
    
    embedded: Optional[dict] = None

    def repl(m: re.Match) -> str:
        nonlocal embedded
        info = m.group(2).strip().lower()
        if PACK_FENCE_TAG in info.split() and embedded is None:
            try:
                embedded = json.loads(m.group(3))
            except json.JSONDecodeError as e:
                raise PackError(f"embedded skillc-pack block is not valid JSON: {e}")
        return "\n" * m.group(0).count("\n")

    return FENCE_RE.sub(repl, body), embedded


def _classify(raw: str) -> Optional[str]:
    
    if ":" in raw:
        return None                      
    if "." in raw:
        
        return "shell"
    if AGENT_TOOL_RE.match(raw):
        return "agent-tool"
    if SHELL_TOKEN_RE.match(raw):
        return "shell"                   
    return None


def extract(body: str, declared: set[str]) -> list[Invocation]:
    
    out: list[Invocation] = []
    for m in INVOKE_RE.finditer(body):
        
        prefix = body[max(0, m.start() - 20):m.start()]
        if _NEGATION_BEFORE_VERB_RE.search(prefix):
            continue
        raw = m.group(1)
        norm = normalize_tool(raw)
        line = body.count("\n", 0, m.start(1)) + 1
        if norm in declared:
            out.append(Invocation(raw, norm, "agent-tool", line))
            continue
        kind = _classify(raw)
        if kind == "agent-tool" and raw[0].isupper():
            
            
            
            
            kind = "shell"
        if kind == "agent-tool":
            out.append(Invocation(raw, norm, "agent-tool", line))
        elif kind == "shell":
            out.append(Invocation(raw, SHELL_CAP, "shell", line))
    return out


def compile_markdown(text: str, profile: Profile,
                     name: Optional[str] = None) -> CompileResult:
    
    meta, body = parse_frontmatter(text)
    skill_name = str(name or meta.get("name") or "skill")
    prose, embedded = _strip_fences(body)

    if embedded is not None:
        validate_pack(embedded)
        return CompileResult(pack=embedded, name=skill_name,
                             profile=profile.name, embedded=True)

    
    declared: dict[str, str] = {}
    for t in sorted(profile.tools):
        declared[t] = f"profile:{profile.name}"
    for key in ("allowed-tools", "allowed_tools", "tools"):
        for t in _tool_list(meta.get(key)):
            declared[normalize_tool(t)] = f"frontmatter:{key}"
    for m in TOOLS_LINE_RE.finditer(prose):
        for t in m.group(1).rstrip(".").split(","):
            t = t.strip().strip("`")
            if t and re.match(r"\A[A-Za-z][A-Za-z0-9_-]*\Z", t):
                declared[normalize_tool(t)] = "prose:tools-line"

    if profile.shell and SHELL_CAP not in declared:
        declared[SHELL_CAP] = f"profile:{profile.name}(shell)"

    
    invocations = extract(prose, set(declared))

    
    
    
    
    warnings: list[str] = []
    sem = semantic.build(skill_name, prose, declared)
    if sem is not None:
        validate_pack(sem.pack)
        return CompileResult(pack=sem.pack, name=skill_name,
                             profile=profile.name, declared=declared,
                             invocations=invocations, notes=sem.notes)

    if not invocations:
        warnings.append("no tool invocations extracted; goal is trivially "
                        "achievable (the skill demands no tool actions)")

    
    def pred(tool: str) -> str:
        return "used_" + re.sub(r"[^a-z0-9_]", "_", tool)

    capabilities = {t: {"owner": "agent", "add": [pred(t)]}
                    for t in sorted(declared)}
    seen: list[str] = []
    protocol = []
    for inv in invocations:
        protocol.append({"act": {"cap": inv.tool, "by": "agent"}})
        if inv.tool not in seen:
            seen.append(inv.tool)
    goal_conjuncts = [pred(t) for t in seen]
    goal = {"and": goal_conjuncts} if goal_conjuncts else True

    pack = {
        "name": skill_name,
        "roles": ["agent"],
        "capabilities": capabilities,
        "protocol": protocol,
        "goal": goal,
        "init_true": [],
    }
    validate_pack(pack)
    return CompileResult(pack=pack, name=skill_name, profile=profile.name,
                         declared=declared, invocations=invocations,
                         warnings=warnings)


def compile_file(path, profile: Profile, name: Optional[str] = None) -> CompileResult:
    with open(path, encoding="utf-8") as fh:
        return compile_markdown(fh.read(), profile, name=name)
