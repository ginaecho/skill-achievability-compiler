
from __future__ import annotations

import copy
from typing import Any, Optional

from .formula import atoms


def _acts(steps: list[dict]) -> list[str]:
    out = []
    for s in steps:
        if "act" in s:
            out.append(s["act"]["cap"])
        if "choice" in s:
            for br in s["choice"]["branches"].values():
                out.extend(_acts(br))
        if "rec" in s:
            out.extend(_acts(s["rec"]["body"]))
    return out


def drop_invoked_capability(pack: dict) -> Optional[tuple[dict, str]]:
    
    invoked = [c for c in _acts(pack["protocol"]) if c in pack["capabilities"]]
    if not invoked:
        return None
    victim = sorted(invoked)[0]
    mutant = copy.deepcopy(pack)
    del mutant["capabilities"][victim]
    mutant["name"] = pack.get("name", "pack") + f"__drop_{victim}"
    return mutant, victim


def strip_goal_establisher(pack: dict) -> Optional[tuple[dict, str]]:
    
    init = set(pack.get("init_true", []))
    for atom in sorted(atoms(pack["goal"])):
        if atom in init:
            continue
        establishers = [n for n, c in pack["capabilities"].items()
                        if atom in c.get("add", [])]
        if not establishers:
            continue
        mutant = copy.deepcopy(pack)
        for n in establishers:
            mutant["capabilities"][n]["add"] = [
                a for a in mutant["capabilities"][n]["add"] if a != atom]
        mutant["name"] = pack.get("name", "pack") + f"__strip_{atom}"
        return mutant, atom
    return None


def is_conjunctive(goal: Any) -> bool:
    
    if isinstance(goal, str) or goal in (True, False):
        return True
    if isinstance(goal, dict):
        if "and" in goal:
            return all(is_conjunctive(x) for x in goal["and"])
        if "cmp" in goal:
            return True
    return False
