
from __future__ import annotations

import json
import math
import os
import urllib.request
from dataclasses import dataclass, field, replace
from typing import Optional










CHARS_PER_TOKEN = 3.8



CACHE_READ_DISCOUNT = 0.1

TOKEN_COUNT_URL = "https://api.anthropic.com/v1/messages/count_tokens"


def estimate_tokens(text: str, chars_per_token: float = CHARS_PER_TOKEN) -> int:
    
    if not text:
        return 0
    return max(1, math.ceil(len(text) / chars_per_token))


def count_tokens_exact(text: str, model: str = "claude-sonnet-5",
                       system: str = "", timeout: int = 60) -> int:
    
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise RuntimeError("ANTHROPIC_API_KEY is not set; exact token counting "
                           "needs the API -- use estimate_tokens() instead")
    payload: dict = {"model": model,
                     "messages": [{"role": "user", "content": text}]}
    if system:
        payload["system"] = system
    req = urllib.request.Request(
        TOKEN_COUNT_URL, data=json.dumps(payload).encode(),
        headers={"content-type": "application/json", "x-api-key": key,
                 "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return int(json.load(r)["input_tokens"])






@dataclass(frozen=True)
class Price:
    
    name: str
    input_per_mtok: float
    output_per_mtok: float

    def cost(self, input_tokens: int, output_tokens: int,
             cached_input_tokens: int = 0) -> float:
        
        return ((input_tokens * self.input_per_mtok
                 + cached_input_tokens * self.input_per_mtok
                 * CACHE_READ_DISCOUNT
                 + output_tokens * self.output_per_mtok) / 1_000_000)






PRICES = {
    "frontier": Price("frontier tier", input_per_mtok=5.0, output_per_mtok=25.0),
    "mid": Price("mid tier", input_per_mtok=3.0, output_per_mtok=15.0),
    "small": Price("small tier", input_per_mtok=1.0, output_per_mtok=5.0),
}
DEFAULT_PRICE = "mid"






@dataclass(frozen=True)
class Cost:
    
    input_tokens: int = 0
    output_tokens: int = 0
    cached_input_tokens: int = 0     
    measured: bool = False           
    label: str = ""

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens + self.cached_input_tokens

    def usd(self, price: Price | str = DEFAULT_PRICE) -> float:
        p = PRICES[price] if isinstance(price, str) else price
        return p.cost(self.input_tokens, self.output_tokens,
                      self.cached_input_tokens)

    def __add__(self, other: "Cost") -> "Cost":
        return Cost(self.input_tokens + other.input_tokens,
                    self.output_tokens + other.output_tokens,
                    self.cached_input_tokens + other.cached_input_tokens,
                    self.measured and other.measured,
                    self.label or other.label)

    def to_dict(self, price: Price | str = DEFAULT_PRICE) -> dict:
        return {"label": self.label, "input_tokens": self.input_tokens,
                "output_tokens": self.output_tokens,
                "cached_input_tokens": self.cached_input_tokens,
                "total_tokens": self.total_tokens,
                "measured": self.measured,
                "usd": round(self.usd(price), 6)}


ZERO = Cost(label="deterministic (no model in the loop)")


def usage_to_cost(usage: dict, label: str = "compaction") -> Cost:
    
    return Cost(input_tokens=int(usage.get("input_tokens", 0)),
                output_tokens=int(usage.get("output_tokens", 0)),
                cached_input_tokens=int(usage.get("cache_read_input_tokens", 0))
                + int(usage.get("cache_creation_input_tokens", 0)),
                measured=True, label=label)






def compaction_cost(skill_text: str, *, system_text: Optional[str] = None,
                    pack: Optional[dict] = None, repair_rounds: int = 0,
                    chars_per_token: float = CHARS_PER_TOKEN) -> Cost:
    
    if repair_rounds < 0:
        raise ValueError("repair_rounds must be >= 0")
    from .frontend.llm import SYSTEM
    sys_tokens = estimate_tokens(system_text if system_text is not None
                                 else SYSTEM, chars_per_token)
    skill_tokens = estimate_tokens(skill_text, chars_per_token)
    pack_tokens = (estimate_tokens(json.dumps(pack), chars_per_token)
                   if pack is not None else _TYPICAL_PACK_TOKENS)

    inp = sys_tokens + skill_tokens
    out = pack_tokens
    for _ in range(repair_rounds):
        
        
        inp += sys_tokens + skill_tokens + pack_tokens + _COUNTEREXAMPLE_TOKENS
        out += pack_tokens
    return Cost(input_tokens=inp, output_tokens=out,
                label=f"LLM compaction ({repair_rounds} repair round"
                      f"{'' if repair_rounds == 1 else 's'})")




_TYPICAL_PACK_TOKENS = 650

_COUNTEREXAMPLE_TOKENS = 120


def check_cost(skill_text: str = "", *, llm: bool = False,
               repair_rounds: int = 0, **kw) -> Cost:
    
    if not llm:
        return replace(ZERO, label="deterministic front-end + checker")
    return compaction_cost(skill_text, repair_rounds=repair_rounds, **kw)






@dataclass(frozen=True)
class RuntimeModel:
    
    system_tokens: int = 2_500
    skill_tokens: int = 0
    turn_growth_tokens: int = 700
    output_tokens_per_turn: int = 250
    
    
    cache_hit_rate: float = 0.0

    def run_cost(self, turns: int, agents: int = 1) -> Cost:
        
        if turns < 0 or agents < 1:
            raise ValueError("turns must be >= 0 and agents >= 1")
        fixed = self.system_tokens + self.skill_tokens
        raw_input = turns * fixed + self.turn_growth_tokens * turns * (turns - 1) // 2
        output = turns * self.output_tokens_per_turn
        raw_input *= agents
        output *= agents
        cached = int(raw_input * self.cache_hit_rate)
        return Cost(input_tokens=raw_input - cached, output_tokens=output,
                    cached_input_tokens=cached,
                    label=f"{agents} agent(s) x {turns} turns")


@dataclass(frozen=True)
class FailureProfile:
    
    reason: str
    turns: tuple           
    agents: int = 1
    rationale: str = ""
    silent: bool = False   


FAILURE_PROFILES = {
    "MISSING_CAPABILITY": FailureProfile(
        "MISSING_CAPABILITY", (3, 8, 14),
        rationale="the agent calls a tool that is not there, retries once or "
                  "twice, then improvises a workaround -- the improvisation, "
                  "not the error, is what costs turns"),
    "BLOCKED_GUARD": FailureProfile(
        "BLOCKED_GUARD", (12, 25, 50),
        rationale="a precondition no run can satisfy is the retry-forever "
                  "cause: the agent has no way to learn the guard is "
                  "unsatisfiable, so it runs until the harness turn cap"),
    "GOAL_UNSAT": FailureProfile(
        "GOAL_UNSAT", (8, 18, 30), silent=True,
        rationale="the plan executes to the end and only then fails to "
                  "satisfy the goal -- and when a conjunct has no establisher "
                  "the run can terminate *believing* it succeeded, moving the "
                  "cost off the token bill and onto whoever trusted it"),
    "NON_CONFORMANT": FailureProfile(
        "NON_CONFORMANT", (6, 15, 30), agents=2,
        rationale="a role that does not refine its contract diverges from the "
                  "protocol mid-session; both sides burn context before the "
                  "mismatch surfaces"),
    "NON_PROJECTABLE": FailureProfile(
        "NON_PROJECTABLE", (6, 15, 30), agents=2,
        rationale="an unobserved choice deadlocks the handoff: both agents "
                  "hold full context and wait, and both are billed for it "
                  "until a timeout fires"),
}






@dataclass
class Economics:
    
    skill: str
    reason: str
    verification: Cost
    waste_low: Cost
    waste_typical: Cost
    waste_high: Cost
    successful_run: Cost
    profile: FailureProfile
    price: str = DEFAULT_PRICE

    @property
    def breakeven_runs(self) -> float:
        
        w = self.waste_typical.total_tokens
        if self.verification.total_tokens == 0:
            return 0.0
        if w == 0:
            return math.inf
        return self.verification.total_tokens / w

    @property
    def verification_share_of_one_run(self) -> float:
        
        r = self.successful_run.total_tokens
        return 0.0 if r == 0 else self.verification.total_tokens / r

    def to_dict(self) -> dict:
        return {
            "skill": self.skill,
            "reason": self.reason,
            "verification": self.verification.to_dict(self.price),
            "waste_per_run": {
                "low": self.waste_low.to_dict(self.price),
                "typical": self.waste_typical.to_dict(self.price),
                "high": self.waste_high.to_dict(self.price),
            },
            "successful_run": self.successful_run.to_dict(self.price),
            
            "breakeven_runs": (None if math.isinf(self.breakeven_runs)
                               else round(self.breakeven_runs, 4)),
            "verification_share_of_one_run":
                round(self.verification_share_of_one_run, 6),
            "failure_profile": {
                "reason": self.profile.reason,
                "turns": list(self.profile.turns),
                "agents": self.profile.agents,
                "silent": self.profile.silent,
                "rationale": self.profile.rationale,
            },
        }



SUCCESSFUL_RUN_TURNS = 10


def economics(skill_text: str, reason: str, *, name: str = "skill",
              llm: bool = False, repair_rounds: int = 0,
              model: Optional[RuntimeModel] = None,
              verification: Optional[Cost] = None,
              price: str = DEFAULT_PRICE,
              successful_run_turns: int = SUCCESSFUL_RUN_TURNS) -> Economics:
    
    prof = FAILURE_PROFILES.get(reason)
    if prof is None:
        raise KeyError(f"no failure profile for reason {reason!r}; known: "
                       f"{sorted(FAILURE_PROFILES)}")
    rt = model or RuntimeModel()
    rt = replace(rt, skill_tokens=rt.skill_tokens
                 or estimate_tokens(skill_text))
    ver = verification if verification is not None else check_cost(
        skill_text, llm=llm, repair_rounds=repair_rounds)
    lo, ty, hi = prof.turns
    return Economics(
        skill=name, reason=reason, verification=ver,
        waste_low=rt.run_cost(lo, prof.agents),
        waste_typical=rt.run_cost(ty, prof.agents),
        waste_high=rt.run_cost(hi, prof.agents),
        successful_run=rt.run_cost(successful_run_turns),
        profile=prof, price=price)






@dataclass
class CorpusEconomics:
    
    rows: list = field(default_factory=list)
    price: str = DEFAULT_PRICE

    @property
    def refuted(self) -> list:
        return list(self.rows)

    def totals(self) -> dict:
        ver = sum((r.verification for r in self.rows), Cost())
        lo = sum((r.waste_low for r in self.rows), Cost())
        ty = sum((r.waste_typical for r in self.rows), Cost())
        hi = sum((r.waste_high for r in self.rows), Cost())
        return {
            "skills_refuted": len(self.rows),
            "verification_tokens": ver.total_tokens,
            "verification_usd": round(ver.usd(self.price), 4),
            "waste_avoided_tokens": {"low": lo.total_tokens,
                                     "typical": ty.total_tokens,
                                     "high": hi.total_tokens},
            "waste_avoided_usd": {
                "low": round(lo.usd(self.price), 4),
                "typical": round(ty.usd(self.price), 4),
                "high": round(hi.usd(self.price), 4)},
            
            
            "leverage_typical": (None if ver.total_tokens == 0
                                 else round(ty.total_tokens
                                            / ver.total_tokens, 1)),
        }

    def to_dict(self) -> dict:
        return {"price_tier": self.price,
                "totals": self.totals(),
                "skills": [r.to_dict() for r in self.rows]}
