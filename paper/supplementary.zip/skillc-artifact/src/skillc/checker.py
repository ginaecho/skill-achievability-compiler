
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import z3

from .formula import CMP, atoms
from .pack import Capability, Pack, normalize, pack_digest
from .session import ProjectionError, conformance_report, participants, project

REASONS = ("OK", "MISSING_CAPABILITY", "BLOCKED_GUARD", "GOAL_UNSAT",
           "NON_PROJECTABLE", "NON_CONFORMANT", "DYNAMIC_TOPOLOGY")

VERDICT_SCHEMA = "skillc.verdict/1"






SOLVER_TIMEOUT_MS = 10_000


def _skillc_version() -> str:
    from . import __version__          
    return __version__






@dataclass(frozen=True)
class State:
    true_preds: frozenset            
    arith: tuple                     
    version: tuple                   
    path: tuple                      

    def versions(self) -> dict[str, int]:
        return dict(self.version)

    def cur(self, var: str) -> z3.ArithRef:
        v = self.versions().get(var, 0)
        return z3.Int(f"{var}__{v}")


def _mk_state(preds, arith, version: dict[str, int], path) -> State:
    return State(frozenset(preds), tuple(arith),
                 tuple(sorted(version.items())), tuple(path))


def eval_expr(e: Any, st: State) -> z3.ArithRef:
    if isinstance(e, int):
        return z3.IntVal(e)
    if isinstance(e, str):
        return st.cur(e)
    if isinstance(e, dict):
        if "+" in e:
            return eval_expr(e["+"][0], st) + eval_expr(e["+"][1], st)
        if "-" in e:
            return eval_expr(e["-"][0], st) - eval_expr(e["-"][1], st)
        if "*" in e:
            return eval_expr(e["*"][0], st) * eval_expr(e["*"][1], st)
    raise ValueError(f"bad expr: {e!r}")


def eval_formula(f: Any, st: State) -> z3.BoolRef:
    
    if f is True:
        return z3.BoolVal(True)
    if f is False:
        return z3.BoolVal(False)
    if isinstance(f, str):
        return z3.BoolVal(f in st.true_preds)
    if isinstance(f, dict):
        if "and" in f:
            return z3.And([eval_formula(x, st) for x in f["and"]])
        if "or" in f:
            return z3.Or([eval_formula(x, st) for x in f["or"]])
        if "not" in f:
            return z3.Not(eval_formula(f["not"], st))
        if "cmp" in f:
            lhs, op, rhs = f["cmp"]
            return CMP[op](eval_expr(lhs, st), eval_expr(rhs, st))
    raise ValueError(f"bad formula: {f!r}")


def _sat(constraints: list, on_unknown: Callable[[], None] | None = None) -> bool:
    
    s = z3.Solver()
    s.set("timeout", SOLVER_TIMEOUT_MS)
    s.add(*constraints)
    res = s.check()
    if res == z3.unknown and on_unknown is not None:
        on_unknown()
    return res != z3.unsat


def guard_satisfiable(st: State, cap: Capability,
                      on_unknown: Callable[[], None] | None = None) -> bool:
    return _sat(list(st.arith) + [eval_formula(cap.pre, st)], on_unknown)


def apply_effect(st: State, cap: Capability) -> State:
    new_true = set(st.true_preds)
    for a in cap.add:
        new_true.add(a)
    for d in cap.dele:
        new_true.discard(d)
    new_version = st.versions()
    new_arith = list(st.arith)
    
    for v, expr in cap.assigns.items():
        rhs = eval_expr(expr, st)
        new_version[v] = new_version.get(v, 0) + 1
        new_arith.append(z3.Int(f"{v}__{new_version[v]}") == rhs)
    
    for v, constr in cap.nondet.items():
        new_version[v] = new_version.get(v, 0) + 1
        tmp = _mk_state(st.true_preds, new_arith, new_version, st.path)
        new_arith.append(eval_formula(constr, tmp))
    return _mk_state(new_true, new_arith, new_version,
                     st.path + (("act", cap.name),))


def initial_state(p: Pack) -> State:
    st0 = _mk_state(p.init_true, (), {}, ())
    cons = [eval_formula(c, st0) for c in p.init_constraints]
    return _mk_state(p.init_true, cons, {}, ())






def roles_acting(steps: list[dict]) -> set[str]:
    
    return set(participants(steps))


def has_spawn(steps: list[dict]) -> bool:
    
    for s in steps:
        if "spawn" in s:
            return True
        if "choice" in s:
            if any(has_spawn(br) for br in s["choice"]["branches"].values()):
                return True
        if "rec" in s and has_spawn(s["rec"]["body"]):
            return True
    return False






@dataclass
class Verdict:
    achievable: bool
    reason: str = "OK"
    detail: str = ""
    witness: tuple = ()          
    frontier: tuple = ()         
    unknown: bool = False        
    semantics: str = "may"       
    pack_digest: str = ""        
    assumed_conformant: tuple = ()   

    @property
    def label(self) -> str:
        if self.unknown:
            return "UNKNOWN"
        return "ACHIEVABLE" if self.achievable else "IMPOSSIBLE"

    @property
    def refuted(self) -> bool:
        
        return not self.achievable and not self.unknown

    def to_dict(self) -> dict:
        return {
            "schema": VERDICT_SCHEMA,
            "verdict": self.label,
            "reason": self.reason,
            "detail": self.detail,
            "witness": [list(w) for w in self.witness],
            "frontier": list(self.frontier),
            "achievable": self.achievable,
            "refuted": self.refuted,
            "unknown": self.unknown,
            "semantics": self.semantics,
            "assumed_conformant": list(self.assumed_conformant),
            "skillc_version": _skillc_version(),
            "pack_digest": self.pack_digest,
        }


def establishable_atoms(p: Pack) -> frozenset:
    
    out = set(p.init_true)
    for c in p.capabilities.values():
        out |= set(c.add)
    return frozenset(out)


class Checker:
    

    def __init__(self, pack: Pack, semantics: str = "may"):
        if semantics not in ("may", "adversarial"):
            raise ValueError(f"unknown semantics {semantics!r}")
        self.p = pack
        self.semantics = semantics
        self.blocked: list[str] = []     
        self.defeated: list[str] = []    
        self.loop_seen: set = set()      
        self.solver_unknown = False      
        
        
        self.assumed_conformant: tuple = ()

    def _note_solver_unknown(self) -> None:
        self.solver_unknown = True

    def run(self) -> Verdict:
        
        v = self._decide()
        v.semantics = self.semantics
        v.assumed_conformant = self.assumed_conformant
        if self.solver_unknown:
            note = (f"solver returned unknown on at least one query "
                    f"(budget {SOLVER_TIMEOUT_MS} ms); resolved toward "
                    f"satisfiable, so no refutation rests on it")
            v.detail = f"{v.detail} [{note}]" if v.detail else note
        return v

    def _gamma_refutation(self) -> Verdict | None:
        
        can = establishable_atoms(self.p)
        fresh = iter(range(10 ** 9))

        def enc(f: Any) -> z3.BoolRef:
            if f is True:
                return z3.BoolVal(True)
            if f is False:
                return z3.BoolVal(False)
            if isinstance(f, str):
                return z3.Bool(f) if f in can else z3.BoolVal(False)
            if "and" in f:
                return z3.And([enc(x) for x in f["and"]])
            if "or" in f:
                return z3.Or([enc(x) for x in f["or"]])
            if "not" in f:
                return z3.Not(enc(f["not"]))
            if "cmp" in f:
                return z3.Bool(f"__cmp_{next(fresh)}")   
            raise ValueError(f"bad formula: {f!r}")

        if _sat([enc(self.p.goal)], self._note_solver_unknown):
            return None
        dead = tuple(sorted(atoms(self.p.goal) - can))
        return Verdict(False, "GOAL_UNSAT",
                       f"protocol-independent refutation: no capability in "
                       f"Gamma establishes {list(dead)} and the goal cannot "
                       f"hold without them -- every protocol over these "
                       f"capabilities is doomed, spawning included",
                       frontier=dead)

    def _decide(self) -> Verdict:
        
        
        
        missing = self._missing_caps(self.p.protocol)
        if missing:
            return Verdict(False, "MISSING_CAPABILITY",
                           f"protocol invokes undeclared capabilities: {sorted(missing)}",
                           frontier=tuple(sorted(missing)))
        
        
        gamma = self._gamma_refutation()
        if gamma:
            return gamma
        
        
        if has_spawn(self.p.protocol):
            return Verdict(False, "DYNAMIC_TOPOLOGY",
                           "protocol spawns participants at run time; "
                           "achievability is undecidable outside the "
                           "static-topology fragment (Brand-Zafiropulo)",
                           unknown=True)
        
        
        for role in sorted(set(self.p.roles) | roles_acting(self.p.protocol)):
            try:
                project(self.p.protocol, role)
            except ProjectionError as e:
                return Verdict(False, "NON_PROJECTABLE", str(e))
        
        
        
        rep = conformance_report(self.p.skills, self.p.protocol)
        if not rep.ok:
            return Verdict(False, "NON_CONFORMANT", rep.failure)
        self.assumed_conformant = rep.assumed
        
        ok, end_state = self._reach(self.p.protocol, initial_state(self.p), {})
        if ok:
            return Verdict(True, "OK", "goal reachable along witness path",
                           witness=end_state.path)
        if self.defeated:
            uniq = tuple(dict.fromkeys(self.defeated))
            return Verdict(False, "GOAL_UNSAT",
                           "adversarially unachievable: " + "; ".join(uniq),
                           frontier=uniq)
        if self.blocked:
            uniq = tuple(dict.fromkeys(self.blocked))
            return Verdict(False, "BLOCKED_GUARD", "; ".join(uniq), frontier=uniq)
        return Verdict(False, "GOAL_UNSAT",
                       "protocol terminates but no run satisfies the goal "
                       "(goal predicate never established / refinement unsatisfiable)")

    def _missing_caps(self, steps: list[dict]) -> set[str]:
        out: set[str] = set()
        for s in steps:
            if "act" in s and s["act"]["cap"] not in self.p.capabilities:
                out.add(s["act"]["cap"])
            if "choice" in s:
                for br in s["choice"]["branches"].values():
                    out |= self._missing_caps(br)
            if "rec" in s:
                out |= self._missing_caps(s["rec"]["body"])
        return out

    def _goal_sat(self, st: State) -> bool:
        return _sat(list(st.arith) + [eval_formula(self.p.goal, st)],
                    self._note_solver_unknown)

    def _widen(self, st: State, label: str) -> State:
        
        bumped = {v: n + 1 for v, n in st.versions().items()}
        return _mk_state(st.true_preds, (), bumped,
                         st.path + (("continue", label),))

    def _reach(self, steps: list[dict], st: State,
               recenv: dict) -> tuple[bool, State]:
        
        cur = st
        for i, s in enumerate(steps):
            if "goal" in s:                        
                if self._goal_sat(cur):
                    return True, cur
                return False, cur                   
            elif "msg" in s:
                cur = _mk_state(cur.true_preds, cur.arith, cur.versions(),
                                cur.path + (("msg", s["msg"]["label"]),))
            elif "act" in s:
                cap = self.p.capabilities[s["act"]["cap"]]
                if not guard_satisfiable(cur, cap, self._note_solver_unknown):
                    self.blocked.append(
                        f"capability '{cap.name}' guard never satisfiable on "
                        f"this path (pre={cap.pre!r})")
                    return False, cur              
                cur = apply_effect(cur, cap)
            elif "rec" in s:
                
                
                name = s["rec"]["name"]
                unfolding = list(s["rec"]["body"]) + steps[i + 1:]
                return self._reach(unfolding, cur,
                                   {**recenv, name: unfolding})
            elif "continue" in s:
                name = s["continue"]
                key = (name, cur.true_preds)
                if key in self.loop_seen:
                    
                    
                    return False, cur
                self.loop_seen.add(key)
                return self._reach(recenv[name], self._widen(cur, name), recenv)
            elif "choice" in s:
                rest = steps[i + 1:]
                body = s["choice"]
                demonic = (self.semantics == "adversarial"
                           and body.get("external", False))
                last_end = cur
                for label, br in body["branches"].items():
                    branch_state = _mk_state(cur.true_preds, cur.arith,
                                             cur.versions(),
                                             cur.path + (("choose", label),))
                    ok, end = self._reach(list(br) + rest, branch_state, recenv)
                    if demonic:
                        
                        
                        if not ok:
                            self.defeated.append(
                                f"external branch '{label}' of the choice by "
                                f"'{body['by']}' defeats the goal")
                            return False, end
                        last_end = end
                    elif ok:
                        
                        return True, end
                return (True, last_end) if demonic else (False, cur)
        
        if self._goal_sat(cur):
            return True, cur
        return False, cur


def check(pack: dict | Pack, semantics: str = "may") -> Verdict:
    
    p = normalize(pack)
    v = Checker(p, semantics=semantics).run()
    v.pack_digest = pack_digest(p)
    return v
