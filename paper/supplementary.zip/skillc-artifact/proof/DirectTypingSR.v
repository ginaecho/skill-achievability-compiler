Require Import List.
Import ListNotations.

Section DirectTypingSR.
  Context {Role Lab World : Type}.
  Variable role_eq_dec : forall x y : Role, {x = y} + {x <> y}.
  Variable lab_eq_dec  : forall x y : Lab,  {x = y} + {x <> y}.

  Inductive Proc :=
  | PEnd : Proc
  | POut : Role -> Lab -> Proc -> Proc
  | PIn  : Role -> Lab -> Proc -> Proc.

  Inductive Gt :=
  | GEnd  : Gt
  | GComm : Role -> Role -> Lab -> Gt -> Gt
  | GGoal : (World -> Prop) -> Gt -> Gt.

  Definition Sess := Role -> Proc.
  Definition upd (s : Sess) (r : Role) (P : Proc) : Sess :=
    fun r' => if role_eq_dec r' r then P else s r'.

  Lemma upd_same : forall s r P, upd s r P r = P.
  Proof. intros; unfold upd; destruct (role_eq_dec r r); congruence. Qed.

  Lemma upd_other : forall s r P r', r' <> r -> upd s r P r' = s r'.
  Proof. intros; unfold upd; destruct (role_eq_dec r' r); congruence. Qed.

  Lemma upd_comm_pt : forall s a b Pa Pb r,
    a <> b -> upd (upd s a Pa) b Pb r = upd (upd s b Pb) a Pa r.
  Proof.
    intros s a b Pa Pb r Hab. unfold upd.
    destruct (role_eq_dec r b); destruct (role_eq_dec r a); congruence.
  Qed.

  Inductive Lbl := LC : Role -> Lab -> Role -> Lbl.
  Definition inpart (L : Lbl) (r : Role) : Prop :=
    match L with LC p _ q => r = p \/ r = q end.

  Inductive lstep : Lbl -> Sess -> Sess -> Prop :=
  | LS_Comm : forall s p q l Pp Pq,
      p <> q ->
      s p = POut q l Pp ->
      s q = PIn  p l Pq ->
      lstep (LC p l q) s (upd (upd s p Pp) q Pq).

  Inductive ctypes (W : World) : Gt -> Sess -> Prop :=
  | CT_End : forall s,
      (forall r, s r = PEnd) ->
      ctypes W GEnd s
  | CT_Goal : forall phi Gc s,
      phi W ->
      ctypes W Gc s ->
      ctypes W (GGoal phi Gc) s
  | CT_Comm : forall p q l Gc s Pp Pq,
      p <> q ->
      s p = POut q l Pp ->
      s q = PIn  p l Pq ->
      ctypes W Gc (upd (upd s p Pp) q Pq) ->
      ctypes W (GComm p q l Gc) s.

  Lemma ctypes_ext : forall W G s1 s2,
    (forall r, s1 r = s2 r) -> ctypes W G s1 -> ctypes W G s2.
  Proof.
    intros W G s1 s2 Hpt H. revert s2 Hpt.
    induction H as [ s Hend | phi Gc s Hphi Hc IH | p q l Gc s Pp Pq Hpq Hsp Hsq Hc IH ];
      intros s2 Hpt.
    - apply CT_End. intro r. rewrite <- Hpt. apply Hend.
    - apply CT_Goal; [exact Hphi | apply IH; exact Hpt].
    - eapply CT_Comm with (Pp := Pp) (Pq := Pq).
      + exact Hpq.
      + rewrite <- Hpt. exact Hsp.
      + rewrite <- Hpt. exact Hsq.
      + apply IH. intro r. unfold upd. destruct (role_eq_dec r q); destruct (role_eq_dec r p);
          try reflexivity; apply Hpt.
  Qed.

  Inductive gstep (W : World) : Lbl -> Gt -> Gt -> Prop :=
  | GS_CommE : forall p q l Gc,
      gstep W (LC p l q) (GComm p q l Gc) Gc
  | GS_Goal : forall phi Gc L G',
      phi W ->
      gstep W L Gc G' ->
      gstep W L (GGoal phi Gc) G'
  | GS_CommI : forall p q l Gc Gc' L,
      ~ inpart L p -> ~ inpart L q ->
      gstep W L Gc Gc' ->
      gstep W L (GComm p q l Gc) (GComm p q l Gc').

  Theorem subject_reduction :
    forall W G s s' L,
      ctypes W G s ->
      lstep L s s' ->
      exists G', gstep W L G G' /\ ctypes W G' s'.
  Proof.
    intros W G s s' L Ht. revert s' L.
    induction Ht as [ s Hend | phi Gc s Hphi Hc IH | p q l Gc s Pp Pq Hpq Hsp Hsq Hc IH ];
      intros s' L Hstep.
    -
      inversion Hstep; subst.
      match goal with H : s ?x = POut _ _ _ |- _ => rewrite Hend in H; discriminate end.
    -
      destruct (IH s' L Hstep) as [G' [Hg Hc']].
      exists G'. split; [apply GS_Goal; assumption | exact Hc'].
    -
      inversion Hstep as [ ss r t rl mPr mPt Hrt Hsr Hst Heq ]; subst.
      destruct (role_eq_dec r p) as [Hrp | Hrp].
      +
        subst r.
        rewrite Hsp in Hsr. injection Hsr as Et Erl EPr. subst t rl mPr.
        rewrite Hsq in Hst. injection Hst as EPt. subst mPt.
        exists Gc. split; [apply GS_CommE | exact Hc].
      +
        assert (r <> q) as Hrq by (intro; subst; rewrite Hsq in Hsr; discriminate).
        assert (t <> p) as Htp by (intro; subst; rewrite Hsp in Hst; discriminate).
        assert (t <> q) as Htq by
          (intro; subst; rewrite Hsq in Hst; injection Hst as E1 E2 E3; congruence).

        assert (Hstep' : lstep (LC r rl t) (upd (upd s p Pp) q Pq)
                                (upd (upd (upd (upd s p Pp) q Pq) r mPr) t mPt)).
        { apply LS_Comm; [ exact Hrt | | ].
          - rewrite upd_other by congruence. rewrite upd_other by congruence. exact Hsr.
          - rewrite upd_other by congruence. rewrite upd_other by congruence. exact Hst. }
        destruct (IH _ _ Hstep') as [Gc' [Hg Hc']].
        exists (GComm p q l Gc'). split.
        * apply GS_CommI.
          -- simpl; intros [H|H]; congruence.
          -- simpl; intros [H|H]; congruence.
          -- exact Hg.
        * eapply CT_Comm with (Pp := Pp) (Pq := Pq).
          -- exact Hpq.
          -- rewrite upd_other by congruence. rewrite upd_other by congruence. exact Hsp.
          -- rewrite upd_other by congruence. rewrite upd_other by congruence. exact Hsq.
          -- eapply ctypes_ext; [ | exact Hc' ].

             intro r0. unfold upd.
             destruct (role_eq_dec r0 q); destruct (role_eq_dec r0 p);
               destruct (role_eq_dec r0 t); destruct (role_eq_dec r0 r);
               congruence.
  Qed.

  Theorem session_fidelity :
    forall W G G' s L,
      ctypes W G s ->
      gstep W L G G' ->
      exists s', lstep L s s' /\ ctypes W G' s'.
  Proof.
    intros W G G' s L Ht. revert G' L.
    induction Ht as [ s Hend | phi Gc s Hphi Hc IH | p q l Gc s Pp Pq Hpq Hsp Hsq Hc IH ];
      intros G' L Hg.
    -
      inversion Hg.
    -
      inversion Hg; subst.
      match goal with H : gstep W L Gc ?X |- _ =>
        destruct (IH X L H) as [s' [Hl Hc']] end.
      exists s'. split; [exact Hl | exact Hc'].
    -
      inversion Hg; subst.
      +
        exists (upd (upd s p Pp) q Pq). split.
        * apply LS_Comm; assumption.
        * exact Hc.
      +
        destruct L as [r rl t]. simpl in *.
        match goal with Hnp : ~ (p = r \/ p = t) |- _ =>
          assert (r <> p) as Hrp by (intro; subst; apply Hnp; auto);
          assert (t <> p) as Htp by (intro; subst; apply Hnp; auto) end.
        match goal with Hnq : ~ (q = r \/ q = t) |- _ =>
          assert (r <> q) as Hrq by (intro; subst; apply Hnq; auto);
          assert (t <> q) as Htq by (intro; subst; apply Hnq; auto) end.
        match goal with Hg0 : gstep W (LC r rl t) Gc ?X |- _ =>
          destruct (IH X (LC r rl t) Hg0) as [s0 [Hl Hc']] end.

        inversion Hl as [ ss mp mq ml Pr Pt Hrt Hsr Hst Heq ]; subst.
        exists (upd (upd s r Pr) t Pt). split.
        * apply LS_Comm.
          -- exact Hrt.
          -- rewrite upd_other in Hsr by congruence.
             rewrite upd_other in Hsr by congruence. exact Hsr.
          -- rewrite upd_other in Hst by congruence.
             rewrite upd_other in Hst by congruence. exact Hst.
        * eapply CT_Comm with (Pp := Pp) (Pq := Pq).
          -- exact Hpq.
          -- rewrite upd_other by congruence. rewrite upd_other by congruence. exact Hsp.
          -- rewrite upd_other by congruence. rewrite upd_other by congruence. exact Hsq.
          -- eapply ctypes_ext; [ | exact Hc' ].
             intro r0. unfold upd.
             destruct (role_eq_dec r0 t); destruct (role_eq_dec r0 r);
               destruct (role_eq_dec r0 q); destruct (role_eq_dec r0 p);
               congruence.
  Qed.

End DirectTypingSR.
