Require Import List.
Import ListNotations.
Require Import SkillAchievability.

Section DirectTyping.
  Context {Role Cap Lab World : Type}.
  Variable role_eq_dec : forall r1 r2 : Role, {r1 = r2} + {r1 <> r2}.
  Variable eff : Cap -> World -> World -> Prop.

  Inductive Proc :=
  | PEnd  : Proc
  | POut  : Role -> list (Lab * Proc) -> Proc
  | PIn   : Role -> list (Lab * Proc) -> Proc
  | PAct  : Cap  -> Proc -> Proc.

  Inductive G :=
  | GEnd  : G
  | GComm : Role -> Role -> list (Lab * G) -> G
  | GAct  : Cap  -> Role -> G -> G
  | GGoal : (World -> Prop) -> G -> G.

  Definition Sess := Role -> Proc.

  Definition upd (s : Sess) (r : Role) (P : Proc) : Sess :=
    fun r' => if role_eq_dec r' r then P else s r'.

  Definition InPair {A : Type} (l : Lab) (x : A) (xs : list (Lab * A)) : Prop :=
    In (l, x) xs.

  Definition LabSub {A B : Type} (xs : list (Lab*A)) (ys : list (Lab*B)) : Prop :=
    forall l x, InPair l x xs -> exists y, InPair l y ys.

  Inductive step : (Sess * World) -> (Sess * World) -> Prop :=
  | S_Comm : forall (s : Sess) (W : World) (p q : Role) (l : Lab) (P Q : Proc) sendb recvb,
      s p = POut q sendb -> InPair l P sendb ->
      s q = PIn  p recvb -> InPair l Q recvb ->
      step (s, W) (upd (upd s p P) q Q, W)
  | S_Act  : forall (s : Sess) (W W' : World) (p : Role) (a : Cap) (P : Proc),
      s p = PAct a P -> eff a W W' ->
      step (s, W) (upd s p P, W').

  Inductive ctypes : G -> Sess -> World -> Prop :=
  | CT_End  : forall s W,
      (forall r, s r = PEnd) ->
      ctypes GEnd s W
  | CT_Act  : forall a p Gc s W W' P,
      s p = PAct a P ->
      eff a W W' ->
      ctypes Gc (upd s p P) W' ->
      ctypes (GAct a p Gc) s W
  | CT_Goal : forall phi Gc s W,
      phi W ->
      ctypes Gc s W ->
      ctypes (GGoal phi Gc) s W
  | CT_Comm : forall p q gbranches s W sendb recvb,

      p <> q ->
      s p = POut q sendb ->
      s q = PIn  p recvb ->
      gbranches <> nil ->
      LabSub gbranches sendb ->
      LabSub sendb gbranches ->
      LabSub gbranches recvb ->
      (forall l Gl, InPair l Gl gbranches ->
         exists P Q, InPair l P sendb /\ InPair l Q recvb /\
                     ctypes Gl (upd (upd s p P) q Q) W) ->
      ctypes (GComm p q gbranches) s W.

  Inductive Terminal : G -> Prop :=
  | Terminal_End  : Terminal GEnd
  | Terminal_Goal : forall phi Gc, Terminal Gc -> Terminal (GGoal phi Gc).

  Theorem type_directed_safety :
    forall Gt s W,
      ctypes Gt s W ->
      ~ Terminal Gt ->
      exists s' W' Gt', step (s, W) (s', W') /\ ctypes Gt' s' W'.
  Proof.
    intros Gt s W H.
    induction H as [ s W Hend
                    | a p Gc s W W' P Hact Heff Hcont _
                    | phi Gc s W Hphi Hcont IH
                    | p q gbranches s W sendb recvb Hpq Hsp Hsq Hne Hsub_gs Hsub_sg Hsub_gr Hcont ].
    -  intro Hnt. exfalso. apply Hnt. constructor.
    -  intro Hnt.
      exists (upd s p P), W', Gc. split.
      + eapply S_Act; eauto.
      + exact Hcont.
    -  intro Hnt.
      apply IH. intro HTGc. apply Hnt. constructor. exact HTGc.
    -  intro Hnt.
      destruct gbranches as [| [l Gl] grest].
      + congruence.
      + assert (HinG : InPair l Gl ((l, Gl) :: grest)) by (left; reflexivity).
        destruct (Hcont l Gl HinG) as [P [Q [HinP [HinQ HtyC]]]].
        exists (upd (upd s p P) q Q), W, Gl. split.
        * eapply S_Comm; [exact Hsp | exact HinP | exact Hsq | exact HinQ].
        * exact HtyC.
  Qed.

  Corollary progress :
    forall Gt s W,
      ctypes Gt s W ->
      ~ Terminal Gt ->
      exists s' W', step (s, W) (s', W').
  Proof.
    intros Gt s W H Hnt.
    destruct (type_directed_safety Gt s W H Hnt) as [s' [W' [Gt' [Hstep _]]]].
    exists s', W'. exact Hstep.
  Qed.

  Definition Stuck (s : Sess) (W : World) : Prop :=
    ~ exists s' W', step (s, W) (s', W').

  Corollary stuck_untypeable :
    forall Gt s W,
      Stuck s W -> ~ Terminal Gt -> ~ ctypes Gt s W.
  Proof.
    intros Gt s W Hstuck Hnt Hty.
    apply Hstuck. apply (progress Gt s W Hty Hnt).
  Qed.

End DirectTyping.

Module HandoffInstance.

  Inductive Role := Planner | Worker.
  Inductive Cap  := Deliver.
  Inductive Lab  := Req.
  Definition World := bool.

  Definition role_eq_dec : forall r1 r2 : Role, {r1 = r2} + {r1 <> r2}.
  Proof. decide equality. Defined.

  Definition eff (a : Cap) (w w' : World) : Prop := w' = true.

  Definition Done (w : World) : Prop := w = true.

  Definition G_good : @G Role Cap Lab World :=
    GComm Planner Worker
      [(Req, GAct Deliver Worker (GGoal Done GEnd))].

  Definition s_good : @Sess Role Cap Lab :=
    fun r => match r with
             | Planner => POut Worker [(Req, PEnd)]
             | Worker  => PIn  Planner [(Req, PAct Deliver PEnd)]
             end.

  Definition W0 : World := false.

  Lemma good_typed : ctypes role_eq_dec eff G_good s_good W0.
  Proof.
    unfold G_good, s_good.
    eapply CT_Comm.
    - discriminate.
    - reflexivity.
    - reflexivity.
    - discriminate.
    - intros l x Hin. destruct Hin as [Heq | []].
      assert (l = Req) by congruence. subst l.
      exists PEnd. left. reflexivity.
    - intros l x Hin. destruct Hin as [Heq | []].
      assert (l = Req) by congruence. subst l.
      exists (GAct Deliver Worker (GGoal Done GEnd)). left. reflexivity.
    - intros l x Hin. destruct Hin as [Heq | []].
      assert (l = Req) by congruence. subst l.
      exists (PAct Deliver PEnd). left. reflexivity.
    - intros l Gl Hin. destruct Hin as [Heq | []].
      assert (l = Req) by congruence.
      assert (Gl = GAct Deliver Worker (GGoal Done GEnd)) by congruence. subst l Gl.
      exists PEnd.
      exists (PAct Deliver PEnd).
      repeat split.
      + left. reflexivity.
      + left. reflexivity.
      + eapply CT_Act.
        * unfold upd. destruct (role_eq_dec Worker Planner) as [E|_]; [discriminate E|].
          destruct (role_eq_dec Worker Worker) as [_|Ne]; [reflexivity | congruence].
        * reflexivity.
        * eapply CT_Goal.
          -- reflexivity.
          -- apply CT_End. intro r.
             unfold upd. destruct r.
             ++ destruct (role_eq_dec Planner Worker) as [E|_]; [discriminate E|].
                destruct (role_eq_dec Planner Planner) as [_|Ne]; [reflexivity | congruence].
             ++ destruct (role_eq_dec Worker Worker) as [_|Ne]; [reflexivity | congruence].
  Qed.

  Lemma good_runs_to_goal :
    exists sf, reach (step role_eq_dec eff) (s_good, W0) (sf, true).
  Proof.
    eexists.
    eapply reach_step.
    - eapply reach_step.
      + apply reach_refl.
      + eapply S_Comm with (p := Planner) (q := Worker) (l := Req);
          [reflexivity | left; reflexivity | reflexivity | left; reflexivity].
    - eapply S_Act with (p := Worker) (a := Deliver); [reflexivity | reflexivity].
  Qed.

  Definition s_bad : @Sess Role Cap Lab :=
    fun r => match r with
             | Planner => PIn Worker  [(Req, PEnd)]
             | Worker  => PIn Planner [(Req, PEnd)]
             end.

  Lemma bad_stuck : Stuck role_eq_dec eff s_bad W0.
  Proof.
    intros [s' [W' Hstep]].
    inversion Hstep; subst.
    - match goal with H : s_bad ?p = POut _ _ |- _ => destruct p; simpl in H; discriminate H end.
    - match goal with H : s_bad ?p = PAct _ _ |- _ => destruct p; simpl in H; discriminate H end.
  Qed.

  Corollary bad_untypeable :
    forall Gt, ~ Terminal Gt -> ~ ctypes role_eq_dec eff Gt s_bad W0.
  Proof.
    intros Gt Hnt.
    exact (stuck_untypeable role_eq_dec eff Gt s_bad W0 bad_stuck Hnt).
  Qed.

End HandoffInstance.
