Section Reachability.
  Context {St : Type}.
  Variable step : St -> St -> Prop.

  Inductive reach (s : St) : St -> Prop :=
  | reach_refl : reach s s
  | reach_step : forall u v, reach s u -> step u v -> reach s v.

  Lemma reach_one : forall s v, step s v -> reach s v.
  Proof. intros s v H. eapply reach_step. apply reach_refl. exact H. Qed.

  Lemma reach_trans : forall s u v, reach s u -> reach u v -> reach s v.
  Proof.
    intros s u v Hsu Huv. induction Huv as [| x y Hux IH Hxy].
    - exact Hsu.
    - eapply reach_step. apply IH. exact Hxy.
  Qed.
End Reachability.

Lemma reach_mono {St : Type} (step1 step2 : St -> St -> Prop) :
  (forall x y, step1 x y -> step2 x y) ->
  forall s w, reach step1 s w -> reach step2 s w.
Proof.
  intros Hsub s w H. induction H as [| u v Hsu IH Huv].
  - apply reach_refl.
  - eapply reach_step. apply IH. apply Hsub. exact Huv.
Qed.

Section Soundness.
  Context {W A : Type}.
  Variable cstep : W -> W -> Prop.
  Variable astep : A -> A -> Prop.
  Variable abs   : W -> A.
  Variable cgoal : W -> Prop.
  Variable agoal : A -> Prop.

  Hypothesis step_sim : forall w w', cstep w w' -> astep (abs w) (abs w').
  Hypothesis goal_sim : forall w, cgoal w -> agoal (abs w).

  Lemma reach_abs :
    forall s0 w, reach cstep s0 w -> reach astep (abs s0) (abs w).
  Proof.
    intros s0 w H. induction H as [| u v Hsu IH Huv].
    - apply reach_refl.
    - eapply reach_step. apply IH. apply step_sim. exact Huv.
  Qed.

  Theorem refutation_sound :
    forall s0,
      (~ exists a, reach astep (abs s0) a /\ agoal a) ->
      (~ exists w, reach cstep s0 w /\ cgoal w).
  Proof.
    intros s0 Hno [w [Hreach Hgoal]].
    apply Hno. exists (abs w). split.
    - apply reach_abs. exact Hreach.
    - apply goal_sim. exact Hgoal.
  Qed.
End Soundness.

Section Tolerance.
  Context {A : Type}.
  Variables fine coarse : A -> A -> Prop.
  Hypothesis over : forall x y, fine x y -> coarse x y.
  Variable agoal : A -> Prop.

  Theorem tolerance_sound :
    forall s0,
      (~ exists a, reach coarse s0 a /\ agoal a) ->
      (~ exists a, reach fine s0 a /\ agoal a).
  Proof.
    intros s0 Hno [a [Hreach Hgoal]].
    apply Hno. exists a. split.
    - apply (reach_mono fine coarse over). exact Hreach.
    - exact Hgoal.
  Qed.
End Tolerance.

Section CapabilityMonotone.
  Context {A : Type}.
  Variables stepLo stepHi : A -> A -> Prop.
  Hypothesis grant : forall x y, stepLo x y -> stepHi x y.
  Variable agoal : A -> Prop.

  Theorem cap_monotone :
    forall s0 a, reach stepLo s0 a -> agoal a ->
                 exists a', reach stepHi s0 a' /\ agoal a'.
  Proof.
    intros s0 a Hreach Hgoal. exists a. split.
    - apply (reach_mono stepLo stepHi grant). exact Hreach.
    - exact Hgoal.
  Qed.
End CapabilityMonotone.

Module FlightInstance.

  Record World := mk {
    searched : bool;
    filtered : bool;
    booked   : bool;
    conf     : bool
  }.

  Inductive cstep : World -> World -> Prop :=
  | do_search : forall w,
      cstep w (mk true (filtered w) (booked w) (conf w))
  | do_filter : forall w,
      searched w = true ->
      cstep w (mk (searched w) true (booked w) (conf w))
  | do_book : forall w,
      filtered w = true ->
      cstep w (mk (searched w) (filtered w) true (conf w)).

  Definition s0 : World := mk false false false false.
  Definition cgoal (w : World) : Prop := booked w = true /\ conf w = true.

  Lemma step_preserves_conf : forall w w', cstep w w' -> conf w' = conf w.
  Proof. intros w w' H. destruct H; simpl; reflexivity. Qed.

  Lemma conf_stays_false : forall w, reach cstep s0 w -> conf w = false.
  Proof.
    intros w H. induction H as [| u v Hsu IH Huv].
    - reflexivity.
    - rewrite (step_preserves_conf u v Huv). exact IH.
  Qed.

  Theorem flight_refuted : ~ exists w, reach cstep s0 w /\ cgoal w.
  Proof.
    intros [w [Hreach [_ Hconf]]].
    rewrite (conf_stays_false w Hreach) in Hconf. discriminate Hconf.
  Qed.

  Theorem booking_reachable :
    exists w, reach cstep s0 w /\ booked w = true.
  Proof.
    exists (mk true true true false). split.
    - eapply reach_step.
      eapply reach_step.
      eapply reach_step.
      apply reach_refl.

      apply (do_search s0).

      apply (do_filter (mk true false false false)). reflexivity.

      apply (do_book (mk true true false false)). reflexivity.
    - reflexivity.
  Qed.

End FlightInstance.
