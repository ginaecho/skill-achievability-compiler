# skillc — Skill Achievability Compiler

Supplementary artifact. `skillc` decides, before execution, whether the goal
declared by an agent skill can be achieved with the capabilities and protocol
the skill declares. An `IMPOSSIBLE` verdict is sound; an `ACHIEVABLE` verdict
is a statement about the abstract search.

## Requirements

- Python 3.10 or newer
- Coq 8.18 or newer (only to re-check the proofs in `proof/`)

## Install

    pip install -e .

This installs the `skillc` command and its two dependencies (z3-solver, pyyaml).

## Run

Decide achievability for one skill or pack:

    skillc check corpus/skills/book_flight_ok/SKILL.md

Reproduce the evaluation reported in the paper (15-case matrix and the
extended suite):

    skillc eval

Batch-check every skill under a directory:

    skillc scan corpus/skills

Other subcommands: `compile` (markdown to pack), `audit`, `cost`, `profiles`.
Use `skillc <subcommand> --help` for options.

## Test

    pip install -e ".[dev]"
    pytest

## Proofs

The mechanized soundness core is in `proof/`:

- `SkillAchievability.v` — refutation soundness, tolerance, capability
  monotonicity, and the concrete flight instance
- `DirectTypingSR.v` — subject reduction and session fidelity
- `DirectTyping.v` — head-move safety, progress, the handoff instances

Check them with:

    coqc proof/SkillAchievability.v
    coqc proof/DirectTyping.v
    coqc proof/DirectTypingSR.v

`check_assumptions.v` and `check_direct_typing.v` print the axiom usage of the
main results; both report closure under the global context.

## Layout

    src/skillc/   the checker
    proof/        Coq development
    corpus/       evaluation corpus
    tests/        test suite
    examples/     example skills
