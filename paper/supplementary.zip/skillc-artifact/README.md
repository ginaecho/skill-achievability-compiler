# skillc — Skill Achievability Compiler

Supplementary artifact. `skillc` decides, before execution, whether the goal
declared by an agent skill can be achieved with the capabilities and protocol
that skill declares. An `IMPOSSIBLE` verdict is sound; an `ACHIEVABLE` verdict
is a statement about the abstract search.

## Requirements

- Python 3.10 or newer
- Coq 8.18 or newer (only to re-check the proofs in `proof/`)

## Install

    pip install -e .

Installs the `skillc` command and its dependencies (z3-solver, pyyaml).

## Run

Decide achievability for one skill:

    skillc check corpus/skills/book_flight_ok/SKILL.md

Reproduce the evaluation reported in the paper:

    skillc eval

Batch-check every skill under a directory:

    skillc scan corpus/skills

Further subcommands: `compile` (markdown to pack), `audit`, `cost`,
`profiles`. Run `skillc <subcommand> --help` for options.

## Test

    pip install -e ".[dev]"
    pytest

## Proofs

The mechanized soundness core is in `proof/`:

- `SkillAchievability.v` — refutation soundness, tolerance, capability
  monotonicity, and the flight instance
- `DirectTypingSR.v` — subject reduction and session fidelity
- `DirectTyping.v` — head-move safety, progress, the handoff instances

Re-check them with:

    coqc proof/SkillAchievability.v
    coqc proof/DirectTyping.v
    coqc proof/DirectTypingSR.v

`check_assumptions.v` and `check_direct_typing.v` report the axiom usage of
the main results; both print closure under the global context.

## Layout

    src/skillc/   the checker; data/ holds the capability profiles
    proof/        Coq development
    corpus/       evaluation corpus (the packs behind the reported matrix)
    scripts/      corpus build, token-economics benchmark, reporting
    tests/        test suite
    examples/     example skills

The scripts that call a model read their endpoint and key from the
environment (`AZURE_OPENAI_ENDPOINT` / `AZURE_OPENAI_API_KEY`, or
`ANTHROPIC_API_KEY`); the value in the source is a placeholder. The checker
itself uses no model and needs no credentials.
